export const educations = [
  {
    id: 1,
    title: "Bachelor Degree",
    duration: "2020 - Present",
    institution: "National University of Bangladesh",
  },
  {
    id: 2,
    title: "Higher Secondary Certificate",
    duration: "2018 - 2020",
    institution: "Noakhali Islamia Kamil Madrasah",
  },
  {
    id: 3,
    title: "Secondary School Certificate",
    duration: "2008 - 2018",
    institution: "Baitus Saif Islamia Madrasah",
  }
]